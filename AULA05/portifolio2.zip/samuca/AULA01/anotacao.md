(!) abre uma nova estrutura html
doctype e o tipo de de linguagen de marcacao
alt+ shif +f  organiza o codigo